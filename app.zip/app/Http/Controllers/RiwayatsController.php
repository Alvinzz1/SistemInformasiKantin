<?php

namespace App\Http\Controllers;

use App\Models\History;
// use Barryvdh\DomPDF\PDF;
use App\Models\Transaction;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Barryvdh\DomPDF\Facade\Pdf;
// use Illuminate\Support\Facades\Pdf;
use Illuminate\Foundation\Auth\User;
use Illuminate\Support\Facades\Auth;


class RiwayatsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        // $userId = Auth::id();
        // $user = User::with('carts')->find($userId);
        $details = Transaction::all();
        return view('dashboard.riwayats.index', [
            // 'carts' => $user->carts,
            'histories' => $details,
        ]);
    }

    public function cetakRiwayat(Request $request)
    {

        $riwayat = History::all();
        
        $pdf = PDF::loadview('dashboard.riwayats.cetak-History',['riwayat'=>$riwayat]);

        return $pdf->download();
    }


    

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $details = Transaction::find($id);
        $details->history()->delete();
        $details->delete();
        return redirect('/dashboard/admin/riwayats')->with('success', 'Riwayat berhasil dihapus');
    }
}
