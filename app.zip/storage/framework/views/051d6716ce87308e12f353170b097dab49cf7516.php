
<?php $__env->startSection('content'); ?>
<h1>halaman barang</h1>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Laboriosam nobis praesentium quae laudantium. Deleniti mollitia exercitationem quod nisi aut aliquid.</p>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sistem-kantin-alpin\resources\views/dashboard/barang/index.blade.php ENDPATH**/ ?>