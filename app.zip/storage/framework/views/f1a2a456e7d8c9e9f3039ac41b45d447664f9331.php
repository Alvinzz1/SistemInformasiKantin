
<?php $__env->startSection('content'); ?>
<h1>halaman Riwayat Pembelian</h1>
<div class="table-responsive">

    <!--Table-->
    <table class="table">
  
      <!--Table head-->
      <thead>
        <tr>
          <th>No</th>
          <th class="th-sm">Foto</th>
          <th class="th-sm">Nama Produk</th>
          <th class="th-sm">Qty</th>
          <th class="th-sm">Tanggal Pembelian</th>
          <th class="th-sm">Action</th>
        </tr>
      </thead>
      <!--Table head-->
  
      <!--Table body-->
      <tbody>
        <tr>
          <th scope="row">1</th>
          <td><img src="/template/assets/img/citato.png" width="100" height="100"></td>
          <td>izz</td>  
          <td>100</td>
          <td>3-13-2023</td>
          <td>
            <div class="d-flex align-items-center"><i class="fa fa-trash mb-1 text-danger"></i></div>
          </div>
          </td>
        </tr>
               
      </tbody>
      <!--Table body-->
  
    </table>
    <!--Table-->
  
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sistem-kantin-alpin\resources\views/dashboard/riwayat/index.blade.php ENDPATH**/ ?>