
<?php $__env->startSection('content'); ?>
<h1>halaman Riwayat Pembelian</h1>
<div class="table-responsive">

    <!--Table-->
    <table class="table">
  
      <!--Table head-->
      <thead>
        <tr>
          <th>No</th>
          <th class="th-sm">Nama Produk</th>
          <th class="th-sm">Qty</th>
          <th class="th-sm">Harga</th>
          <th class="th-sm">Tanggal Pembelian</th>
          <th class="th-sm">Action</th>
        </tr>
      </thead>
      <!--Table head-->
  
      <!--Table body-->
      <tbody>
        <tr>
          <th scope="row">1</th>
          <td><img src="/template/assets/img/citato.png" width="100" height="100"></td>
          <td>Hafiz tampan</td>  
          <td>10</td>
          <td>3-13-2023</td>
          <td>
            <div class="btn btn-danger d-flex align-items-center"><i class="fa fa-trash mb-1 text-danger"></i></div>
          </div>
          </td>
        </tr>

        <?php $__currentLoopData = $histories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <?php $__currentLoopData = $h->history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>  
          <td><?php echo e($hs->product->name); ?></td>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <td><?php echo e($h->total); ?></td>
            <td><?php echo e($h->qty); ?></td>
            <td><?php echo e($h->created_at); ?></td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
      </tbody>
      <!--Table body-->
  
    </table>
    <!--Table-->
  
  </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('sidebar.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sistem-kantin-alpin\resources\views/dashboard/Riwayats/index.blade.php ENDPATH**/ ?>