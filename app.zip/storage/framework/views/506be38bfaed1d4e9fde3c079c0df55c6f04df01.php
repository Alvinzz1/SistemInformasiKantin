
<?php $__env->startSection('content'); ?>
<h1>halaman product</h1>


<div class="row justify-content-end">
  <div class="col-md-6">
    <form action="/dashboard/admin/products">
      <div class="input-group mb-3">
        <input type="text" class="form-control" style=" border: 2px solid #2bee15;" placeholder="cari nama product?" name="search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </div>
    </form>
  </div>
</div>


    <?php if(session()->has('success')): ?>

    <div class="alert alert-success" role="alert">
      <?php echo e(session('success')); ?>

      
    </div>
      
    <?php endif; ?>


<div class="table-responsive">
  <a href="/dashboard/admin/products/create" class="btn btn-success mb-3">Tambah Data</a>

    <!--Table-->
    <table class="table">
  
      <!--Table head-->
      <thead>
        <tr>
          <th>No</th>
          <th class="th-sm">Nama Produk</th>  
          <th class="th-sm">Harga</th>
          <th class="th-sm">Deskripsi</th>
          <th class="th-sm">Foto</th>
          <th class="th-sm">Action</th>
        </tr>
      </thead>
      <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <td><?php echo e($loop->iteration); ?></td>
        <td><?php echo e($product->name); ?></td>
        <td><?php echo e($product->harga); ?></td>
        <td><?php echo e($product->desc); ?></td>
        
        <td>
          <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="" width="100px">
        </td>
        <td>

          <a href="/dashboard/admin/products/edit/<?php echo e($product->id); ?>" class="btn btn-success"><i class="bi bi-pencil-square"></i></a>

          <form action="<?php echo e(route('delete-barang',$product->id)); ?>" method="post" class="d-inline" enctype="multipart/form-data">
              <?php echo method_field('delete'); ?>
              <?php echo csrf_field(); ?>
              <button type="submit" class="btn btn-danger" data-id="" 
              onclick="return confirm ('are you sure?')"><i class="bi bi-trash-fill"></i></button>    
          </form> 
        </td>
      </tr>


          


      
            
                
          
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <!--Table head-->
  
      <!--Table body-->
      <tbody>
        
               
      </tbody>
      <!--Table body-->
  
    </table>
    <!--Table-->
  
  </div>  
  <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


  <?php echo e($products->links()); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('sidebar.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sistem-kantin-alpin\resources\views/dashboard/products/index.blade.php ENDPATH**/ ?>