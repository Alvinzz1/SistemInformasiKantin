<!DOCTYPE html>
<html>
<head>
	<title>Membuat Laporan PDF Dengan DOMPDF Laravel</title>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
</head>
<body>
	<style type="text/css">
		table tr td,
		table tr th{
			font-size: 9pt;
		}
	</style>
	<center>
		<h5>Cetak Laporan Penjualan</h4>
	</center>
 
	<table class='table table-bordered'>
		<thead>
			<tr>
				<th>No</th>
				<th>Nama Produk</th>
				<th>Qty</th>
				<th>Harga</th>
				<th>Tanggal Pembelian</th>
				<th>Status</th>
				
			</tr>
		</thead>
		<tbody>
			
            <?php $__currentLoopData = $riwayat; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td><?php echo e($loop->iteration); ?></td>
              <td>
                    <p><?php echo e($p->product->name); ?></p>
              </td>
              <td>
                    <p><?php echo e($p->qty); ?></p>
              </td>
              <td><?php echo e($p->product->harga); ?></td>
              <td><?php echo e($p->created_at); ?></td>
              <td><?php echo e($p->status); ?></td>
              <td></td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
		</tbody>
	</table>
 
</body>
</html><?php /**PATH D:\sistem-kantin-alpin\resources\views/dashboard/riwayats/cetak-History.blade.php ENDPATH**/ ?>