
<?php $__env->startSection('content'); ?>
<h1>Admin</h1>





<?php $__env->stopSection(); ?>
<?php echo $__env->make('sidebar.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sistem-kantin-alpin\resources\views/dashboard/home/index.blade.php ENDPATH**/ ?>