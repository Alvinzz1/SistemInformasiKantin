
<?php $__env->startSection('content'); ?>
    <h1>Halaman Keranjang</h1>
    
    
    <div class="container mt-5 mb-5">
        <div class="d-flex justify-content-center row">
            <div class="col-md-8">
                <div class="p-2">
                    <h4>Shopping cart</h4>
                </div>
                
                    <div class="d-flex justify-content-end mb-3">
                        <a href="/dashboard/product" class="btn btn-success bi bi-box-arrow-left mr-3 btn-lg active">Belanja Lagi</a>
                    </div>

                <?php if(session()->has('success')): ?>

                <div class="alert alert-success" role="alert">
                  <?php echo e(session('success')); ?>

                  
                </div>
                  
                <?php endif; ?>

                <?php
                    $total = 0;
                ?>
                
                <?php $__currentLoopData = $carts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cart): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="d-flex flex-row justify-content-between align-items-center p-2 bg-white mt-4 px-3 rounded">
                        <div class="mr-1">
                            <img class="rounded" src="<?php echo e(asset('storage/'.$cart->product->image)); ?>" width="70">
                        </div>
                        <div class="d-flex flex-column align-items-center product-details">
                            <span class="font-weight-bold"><?php echo e($cart->product->name); ?></span>
                            <div class="d-flex flex-row product-desc">
                            </div>
                        </div>
                        <form action="/cart/min/<?php echo e($cart->id); ?>" method="post" class="inline ml-2">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($cart->product_id); ?>">
                            <input type="hidden" name="qty" value="<?php echo e($cart->qty - 1); ?>">
                            <button type="submit" class="btn btn-danger">-</button>
                        </form>
                        <h5><?php echo e($cart->qty); ?></h5>
                        <form method="post" action="/cart/plus/<?php echo e($cart->id); ?>" class="inline ml-2">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('put'); ?>
                            <input type="hidden" name="product_id" value="<?php echo e($cart->product_id); ?>">
                            <input type="hidden" name="qty" value="<?php echo e($cart->qty + 1); ?>">
                            <button type="submit" class="btn btn-success">+</button>
                        </form>
                        
                        <div>
                            <h5 class="text-grey">Rp.<?php echo e(number_format($cart->product->harga * $cart->qty, 0, ',', '.')); ?></h5>
                        </div>
                        
                        <form action="<?php echo e(route('delete-product',$cart->id)); ?>" method="post" class="d-inline" enctype="multipart/form-data">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger" data-id="" 
                            onclick="return confirm ('are you sure?')"><i class="bi bi-trash-fill"></i></button>    
                        </form> 
                    </div>

                    <?php
                        $total += ($cart->product->harga * $cart->qty);
                    ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                
                    <div class="total d-flex justify-content-between">
                        <h4 class="total-price">Total Harga Rp.<?php echo e(number_format ($total)); ?></h4>
                    </div>  
                

                
                
                
                <div class="d-flex flex-row align-items-center mt-3 p-2 bg-white rounded">
                    <form action="<?php echo e(route('checkout')); ?>" method="post">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="total" value="<?php echo e($total); ?>">
                          <button class="btn btn-warning btn-block btn-lg ml-2 pay-button" type="submit">Checkout</button>
                    </form>
                </div>
            </div>
        </div>
    </div> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sistem-kantin-alpin\resources\views/dashboard/cart/index.blade.php ENDPATH**/ ?>