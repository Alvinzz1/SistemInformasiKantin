

<?php $__env->startSection('content'); ?>
    <h1>Halaman Saran</h1>

    <?php if(session()->has('success')): ?>
        <div class="alert alert-success" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <table class="table">
        <thead>
            <tr>
                <th scope="col">No</th>
                <th scope="col">Nama</th>
                <th scope="col">Isi Saran</th>
                <th scope="col">Tanggal Masuk</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $saran; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($loop->iteration); ?></th>
                    <td><?php echo e($s->sender); ?></td>
                    <td class="px-6 py-4">
                        <?php echo e(str_replace($sensor, $replace, $s->saran)); ?>

                    </td>
                    <td><?php echo e($s->created_at); ?></td>
                    <td>
                        <form action="<?php echo e(route('delete-saran', $s->id)); ?>" method="post" class="d-inline" enctype="multipart/form-data">
                            <?php echo method_field('delete'); ?>
                            <?php echo csrf_field(); ?>
                            <button type="submit" class="btn btn-danger" data-id="" onclick="return confirm('Are you sure?')">
                                <i class="bi bi-trash-fill"></i>
                            </button>
                        </form> 
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
        
    <?php echo e($saran->links()); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('sidebar.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\sistem-kantin-alpin\resources\views/dashboard/sarans/index.blade.php ENDPATH**/ ?>