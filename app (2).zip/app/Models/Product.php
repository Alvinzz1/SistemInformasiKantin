<?php

namespace App\Models;

use App\Models\Cart;
use App\Models\History;
use App\Models\Category;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;

class Product extends Model
{
    use HasFactory;

    protected $guarded = ['id'];

    public function category()
    {
        return $this->belongsTo(Category::class);
    }

    public function cart()
    {
        return $this->belongsTo(Cart::class);
    }

    public function history()
    {
        return $this->hasMany(History::class, 'product_id', 'id');
    }
}
