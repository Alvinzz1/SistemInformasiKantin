require('./bootstrap');
import Chart from 'chart.js/auto';
